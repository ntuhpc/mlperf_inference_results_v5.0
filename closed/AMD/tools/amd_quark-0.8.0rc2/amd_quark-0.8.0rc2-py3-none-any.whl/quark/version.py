__version__ = '0.8.0rc2'
git_version = '1f92cf5f2b'
is_release = True
